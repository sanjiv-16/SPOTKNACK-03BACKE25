public class Main {
    static final double PI = 3.14;

    /**
     * main method
     * @param args to print
     * @return void
     */
    public static void main(String[] args) {
        pi = 3.15;
        int age = 20;

        age = 21;
        //print stmt
        /*
        test
        teshjk

         */
        System.out.println("Hello, World! "+ args[0]);
    }
}